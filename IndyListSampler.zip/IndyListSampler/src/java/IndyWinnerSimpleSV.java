/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;

/**
 * <p>
 * This is a simple servlet that will use JDBC to gather all of the Indy 500
 * winner information from a database and format it into an HTML table.
 * No guarantees of meeting:
 *			Thread safety
 *			Does not adhere to "SOLID":
 *			No DAO pattern etc.
 *			No page scrolling
 * This is "quick and dirty" simple DB table query, formats DB resultset to
 * an HTML table format
 */
@WebServlet(urlPatterns = {"/IndyWinnerSimpleSV"})
public class IndyWinnerSimpleSV extends HttpServlet {

    private final StringBuilder buffer = new StringBuilder();

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /*	Get the URI, Set the content type, and create a printwriter		*/
        String uri = request.getRequestURI();
        response.setContentType("text/html");

        formatPageHeader(buffer);

        /* Get the page number from request parameter, default to 1 if not provided*/
        int pageNumber = 1;
        if (request.getParameter("page") != null) {
            pageNumber = Integer.parseInt(request.getParameter("page"));
        }

        /* Calculate the offset for the SQL query (10 records per page)*/
        int offset = (pageNumber - 1) * 10;

        /* Update the SQL query to use LIMIT and OFFSET for pagination*/
        String query = "SELECT * FROM indywinners ORDER BY YEAR DESC LIMIT 10 OFFSET " + offset;

        /* Execute the query and format the results*/
        sqlQuery("com.mysql.cj.jdbc.Driver", // Database Driver
                 "jdbc:mysql://localhost:3306/indywinners", // Database Name
                 "root", "Rishi@2005", // username and password
                 query, buffer, uri); // Execute the query and generate HTML

        /* Add pagination buttons*/
        addPaginationButtons(buffer, pageNumber);

        buffer.append("</html>");

        /* Send the formatted page back to the client*/
        try (java.io.PrintWriter out = new java.io.PrintWriter(response.getOutputStream())) {
            out.println(buffer.toString());
            out.flush();
        } catch (Exception ex) {
        }
    }

    /* Format the HTML header for the page*/
    private void formatPageHeader(StringBuilder buffer) {
        buffer.append("<html>");
        buffer.append("<head>");
        buffer.append("<title>Indianapolis 500 Winners</title>");
        buffer.append("</head>");
        buffer.append("<h2><center>");
        buffer.append("Indianapolis 500 Winners");
        buffer.append("</center></h2>");
        buffer.append("<br>");
    }

    /* Execute the SQL query and format the result as an HTML table*/
    private void sqlQuery(String driverName, String connectionURL, String user, String pass,
                          String query, StringBuilder buffer, String uri) {
        boolean rc = true;

        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        long startMS = System.currentTimeMillis();
        int rowCount = 0;

        try {
            Class.forName(driverName);
            con = DriverManager.getConnection(connectionURL, user, pass);
            stmt = con.createStatement();
            rs = stmt.executeQuery(query);

            // Format the result set into an HTML table
            rowCount = resultSetToHTML(rs, buffer, uri);

        } catch (Exception ex) {
            buffer.append("Exception!");
            buffer.append(ex.toString());
            rc = false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException sqlEx) {
                // Ignore any errors here
            }
        }

        /* Output statistics if the query was successful*/
        if (rc) {
            long elapsed = System.currentTimeMillis() - startMS;
            buffer.append("<br><i> (");
            buffer.append(rowCount);
            buffer.append(" rows in ");
            buffer.append(elapsed);
            buffer.append("ms) </i>");
        }
    }

    /* Format the result set into an HTML table*/
    private int resultSetToHTML(ResultSet rs, StringBuilder buffer, String uri)
            throws Exception {

        int rowCount = 0;

        buffer.append("<center><table border>");

        ResultSetMetaData rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount();
        buffer.append("<tr>");
        for (int i = 0; i < columnCount; i++) {
            buffer.append("<th>");
            buffer.append(rsmd.getColumnLabel(i + 1));
            buffer.append("</th>");
        }
        buffer.append("</tr>");

        while (rs.next()) {
            rowCount++;

            buffer.append("<tr>");
            for (int i = 0; i < columnCount; i++) {
                String data = rs.getString(i + 1);
                buffer.append("<td>");
                buffer.append(data);
                buffer.append("</td>");
            }
            buffer.append("</tr>");
        }

        buffer.append("</table></center>");

        return rowCount;
    }

    /* Add pagination buttons (Next and Previous)*/
    private void addPaginationButtons(StringBuilder buffer, int pageNumber) {
        buffer.append("<br><center>");

        /* Previous button (only show if pageNumber > 1)*/
        if (pageNumber > 1) {
            buffer.append("<a href='IndyWinnerSimpleSV?page=" + (pageNumber - 1) + "'>Previous</a>");
        }

        /* Next button (always show)*/
        buffer.append(" | <a href='IndyWinnerSimpleSV?page=" + (pageNumber + 1) + "'>Next</a>");

        buffer.append("</center>");
    }
}
